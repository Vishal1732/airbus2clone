import React from 'react';

const FlightDispaly = () => {
  return (
    <div>
      Flight  
    </div>
  );
}

export default FlightDispaly;
